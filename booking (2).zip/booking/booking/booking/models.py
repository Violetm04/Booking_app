from django.db import models

class Booking(models.model):
       student=models.Foreignkey(student, ondelete=models)
       tutor=models.Foreignkey(tutor,ondelete=models)
       subject=models.CharField(max_length=100)
       time=models.DateTimeField()
       notes=models.TextField(blank=True, null=True)
       created_at=models.DateTimeField(auto_now_add=True)
def _str_(self):
      return f"{self.name} -{self.subject}"
    