from django.db import models

class Tutor(models.model):
       name=models.CharField(max_length=100)
       subject=models.CharField(max_length=100)
       available_times=models.DateTimeField()

def _str_(self):
      return f"{self.name} -{self.subject}"
    
    