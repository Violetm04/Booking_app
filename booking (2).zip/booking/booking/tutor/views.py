from django.shortcuts import render
from django.shortcuts import render, redirect


from django.shortcuts import render, redirect
from django.contrib.auth import login as auth_login, authenticate
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User

# Create your views here.
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from datetime import datetime

@login_required
def dashboard(request):
    return render(request, 'tutor/dashboard.html')
def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            auth_login(request, user)  # Log in the user using Django's built-in login function
            return redirect('home')  # Redirect to 'home' URL name after login
        else:
            return render(request, 'login.html', {'error': 'Invalid username or password'})
    
    return render(request, 'login.html')



def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        
        # Check if username already exists
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists.')
            return redirect('signup')  # Redirect to signup page with error message

        # Check if email already exists
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists.')
            return redirect('signup')  # Redirect to signup page with error message
        
        # Create new user
        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()
        
        messages.success(request, 'Registration successful! You can now log in.')
        return redirect('login')  # Redirect to login page after successful signup

    return render(request, 'signup.html')

def upload(request):
    return render(request,'upload.html')

def financialAid(request):
    return render(request,'financialAid.html')